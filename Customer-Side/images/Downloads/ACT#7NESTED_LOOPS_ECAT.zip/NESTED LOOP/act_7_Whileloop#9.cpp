#include <iostream>
using namespace std;
int main()
{
	
	int rows = 1, cols = 2;
	
	while(rows<=3){
		
		int i = 1;    // Initialize the number of stars given in a row
		while(i<=rows){
			cout<<"* ";
			i++;
		}
		cout<<endl;
		rows++;		// Iterate the number of rows 
	}
	while(cols<=3){
		
		int i = 2;
		int j = 1;
		while(i<=3){
			cout<<"  ";
			i++;
		}
		while(j<=cols){
			cout<<"* ";
			j++;
		}
		cout<<endl;
		cols++;
	}
	
}
