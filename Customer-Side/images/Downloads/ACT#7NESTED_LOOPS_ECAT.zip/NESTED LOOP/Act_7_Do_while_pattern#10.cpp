#include <iostream>
using namespace std;
int main()
{
	
	int rows, cols, space;
	
	rows=1;   // Initialize the numbers rows
	do{
		space=1; // print the number of spacing
		do{
			cout<<" "; 
			space++;
		}while(space<=4);
		
		cols=1;     // Initialize the numbers of columns
		do{
			cout<<"* "; // print the number of stars
			cols++;     
		}while(cols<=1);
		
		cout<<endl;
		rows++;
	}
	while(rows<=1);
	
	rows=1;
	do{
		space=1;  
		do{
			cout<<"  ";  
			space++;
		}while(space<=1);
		
		cols=1;
		do{
			cout<<"* ";
			cols++;
		}while(cols<=3);
		
		cout<<endl;
		rows++;
	}
	while(rows<=1);
	
	rows=1;
	do{
		cols=1;
		do{

			cout<<"* ";
			cols++;
		}
		while(cols<=5);
	cout<<endl;
	rows++;
	}
	while(rows<=3);
	
	rows=1;
	do{
		space=1;
		do{
			cout<<"  ";
			space++;
		}while(space<=1);
		
		cols=1;
		do{
			cout<<"* ";
			cols++;
		}while(cols<=3);
		
		cout<<endl;
		rows++;
	}
	while(rows<=1);
	rows=1;
	do{
		space=1;
		do{
			cout<<" ";
			space++;
		}while(space<=4);
		
		cols=1;
		do{
			cout<<"* ";
			cols++;
		}while(cols<=1);
		
		cout<<endl;
		rows++;
	}
	while(rows<=1);
}
