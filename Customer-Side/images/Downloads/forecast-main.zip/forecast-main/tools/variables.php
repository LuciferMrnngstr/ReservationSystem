<?php

    $page_title = "";
    $dashboard = "";
    $application = "";
    $screening = "";
    $programs = "";
    $students = "";
    $faculty = "";
    $settings = "";

?>